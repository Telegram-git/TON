#include "tl_outputer.h"

namespace td {
namespace tl {

tl_outputer::~tl_outputer() {
}

}  // namespace tl
}  // namespace td
