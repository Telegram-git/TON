#pragma once

#include "td/actor/core/ActorInfo.h"

namespace td {
namespace actor {
namespace core {
using SchedulerMessage = ActorInfoPtr;
}  // namespace core
}  // namespace actor
}  // namespace td
