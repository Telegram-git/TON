#pragma once

namespace vm {

class OpcodeTable;

void register_stack_ops(OpcodeTable& cp0);

}  // namespace vm
