#pragma once

namespace vm {

class OpcodeTable;

void register_ton_ops(OpcodeTable& cp0);

}  // namespace vm
