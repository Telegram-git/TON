#pragma once

namespace vm {

class OpcodeTable;

void register_dictionary_ops(OpcodeTable& cp0);

}  // namespace vm
