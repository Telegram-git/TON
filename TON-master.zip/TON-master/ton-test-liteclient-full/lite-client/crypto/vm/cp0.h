#pragma once
#include "vm/dispatch.h"

namespace vm {

class OpcodeTable;

const OpcodeTable* init_op_cp0();

}  // namespace vm
