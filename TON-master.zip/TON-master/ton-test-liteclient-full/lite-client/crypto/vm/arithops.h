#pragma once

namespace vm {

class OpcodeTable;

void register_arith_ops(OpcodeTable& cp0);

}  // namespace vm
