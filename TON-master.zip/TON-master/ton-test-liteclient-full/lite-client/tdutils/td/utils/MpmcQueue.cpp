#include "td/utils/MpmcQueue.h"
namespace td {
detail::MpmcStat stat_;
}
