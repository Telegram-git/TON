#pragma once

#include "td/utils/common.h"

namespace td {

void usleep_for(int32 microseconds);

}  // namespace td
